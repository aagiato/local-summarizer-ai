import json
from load_and_chunk import load_and_chunk_document
from send_to_claud import summarize_chunks_bedrock

def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
        text = body.get("text", "")
        if not text:
            raise ValueError("No text provided")

        # Load and chunk as plain text (not from PDF)
        chunks = load_and_chunk_document(text, is_text=True)
        summaries = summarize_chunks_bedrock(chunks)

        return {
            "statusCode": 200,
            "body": json.dumps({"summaries": summaries})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
