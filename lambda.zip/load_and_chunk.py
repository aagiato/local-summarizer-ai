from chunking import chunk_text_by_words
import fitz  # pymupdf

def load_and_chunk_document(file_or_text, is_text=True):
    if is_text:
        full_text = file_or_text
    else:
        doc = fitz.open(file_or_text)
        full_text = ""
        for page in doc:
            full_text += page.get_text()

    chunks = chunk_text_by_words(full_text)
    return chunks
