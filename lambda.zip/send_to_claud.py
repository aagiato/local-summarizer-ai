import boto3
import json
from load_and_chunk import load_and_chunk_document  # Ensure this file is in the same directory

# Constants
MODEL_ID = "anthropic.claude-3-sonnet-20240229-v1:0"
REGION = "us-east-1"

def summarize_chunks_bedrock(chunks: list[str]) -> list[str]:
    summaries = []
    bedrock = boto3.client("bedrock-runtime", region_name=REGION)

    for i, chunk in enumerate(chunks):
        prompt = f"""
        Human: Summarize the following financial document chunk:

        {chunk}

        Assistant:"""

        body = json.dumps({
            "prompt": prompt,
            "max_tokens_to_sample": 1024,
            "temperature": 0.3,
            "top_k": 250,
            "top_p": 0.999
        })

        try:
            response = bedrock.invoke_model(
                modelId=MODEL_ID,
                contentType="application/json",
                accept="application/json",
                body=body
            )
            result = json.loads(response['body'].read())
            summaries.append(result["completion"])
        except Exception as e:
            summaries.append(f"[Error summarizing chunk {i+1}: {e}]")

    return summaries


