from load_and_chunk import load_and_chunk_document
from send_to_claud import summarize_chunks_bedrock

def main():
    # Step 1: Load and chunk the document
    file_path = "data/7455eba6-bb80-41d3-96b7-12111eae648c.pdf"  # Replace with actual file
    chunks = load_and_chunk_document(file_path)

    # Step 2: Send to Claude via Bedrock
    summaries = summarize_chunks_bedrock(chunks)

    # Step 3a: Print summaries
    for i, summary in enumerate(summaries, 1):
        print(f"\n--- Summary for Chunk {i} ---\n{summary}\n")

    # Step 3b: Write summaries to file
    with open("summaries_output.txt", "w", encoding="utf-8") as f:
        for i, summary in enumerate(summaries, 1):
            f.write(f"\n--- Summary for Chunk {i} ---\n{summary}\n")

if __name__ == "__main__":
    main()
